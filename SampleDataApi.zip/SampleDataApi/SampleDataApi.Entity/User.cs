﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleDataApi.Entity
{
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string ManagerName { get; set; }
        public string DepartmentName { get; set; }
        public string RoleName { get; set; }
        public string Address { get; set; }
        public int ManagerId { get; set; }
        public int DepartmentId { get; set; }
        public int RoleId { get; set; }
        public int BuildingId { get; set; }
        public int IsEdit { get; set; }
        public bool IsManager { get; set; }
    }
    public class ManagerUpdateParam
    {
        public int UserId { get; set; }
        public int ManagerId { get; set; }
    }
}
