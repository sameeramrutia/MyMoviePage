﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace SampleDataApi.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
        
        
    }
    public class DataService
    {
        public List<UserData> GenerateData(int count)
        {
            var data = new List<UserData>();
            var surnames = new List<string> { "Smith", "Johnson", "Brown", "Taylor", "Anderson", "Harris", "Clark", "Allen", "Scott", "Carter" };
            var names = new List<string> { "James", "John", "Robert", "Christopher", "George", "Mary", "Nancy", "Sandra", "Michelle", "Betty" };
            var gender = new List<string> { "Male", "Female" };
            var startBirthDate = DateTime.Parse("1/1/1975");
            var endBirthDate = DateTime.Parse("1/1/1992");
            double s = 55;

            Func<double> random = () =>
            {
                s = Math.Sin(s) * 10000;
                return s - Math.Floor(s);
            };

            for (var i = 0; i < count; i++)
            {
                var birthDate = new DateTime(startBirthDate.Ticks + Convert.ToInt64(Math.Floor(random() * (endBirthDate.Ticks - startBirthDate.Ticks))));

                birthDate.AddHours(12);

                var nameIndex = Convert.ToInt32(Math.Floor(random() * names.Count));
                var user = new UserData
                {
                    ID = i + 1,
                    FirstName = names[nameIndex],
                    LastName = surnames[Convert.ToInt32(Math.Floor(random() * surnames.Count))],
                    Gender = gender[Convert.ToInt32(Math.Floor(Convert.ToDouble(nameIndex / 5)))],
                    BirthDate = birthDate
                };

                data.Add(user);
            }

            return data;
        }
    }
    public class UserData
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public DateTime BirthDate { get; set; }
        public string Department { get; set; }
        public DateTime JoiningDate { get; set; }
        public string Hometown { get; set; }
    }
}