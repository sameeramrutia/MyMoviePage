﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SampleDataApi.Service;
using SampleDataApi.Service.RepositoryService;
using System.Web.Http.Cors;
using SampleDataApi.Entity;

namespace SampleDataApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/Data")]
    public class DataController : ApiController
    {
        
        [Route("GetAllUsers")]
        [HttpGet]
        public HttpResponseMessage GetUsers(HttpRequestMessage request)
        {
            SampleDataAppService objSampleDataService = new SampleDataAppService();
            var _result = objSampleDataService.GetAllUsers();
            return request.CreateResponse(HttpStatusCode.OK,_result );
        }
        
        [Route("GetAllBuildings")]
        [HttpGet]        
        public HttpResponseMessage GetAllBuildings(HttpRequestMessage request)
        {
            SampleDataAppService objSampleDataService = new SampleDataAppService();
            var _result = objSampleDataService.GetAllBuilding();
            return request.CreateResponse(HttpStatusCode.OK, _result);
        }
        
        
        [Route("GetAllRoles")]
        [HttpGet]
        public HttpResponseMessage GetAllRoles(HttpRequestMessage request)
        {
            SampleDataAppService objSampleDataService = new SampleDataAppService();
            var _result = objSampleDataService.GetAllRoles();
            return request.CreateResponse(HttpStatusCode.OK, _result);
        }

        
        [Route("GetAllDepartments")]
        [HttpGet]
        public HttpResponseMessage GetAllDepartments(HttpRequestMessage request)
        {
            SampleDataAppService objSampleDataService = new SampleDataAppService();
            var _result = objSampleDataService.GetAllDepartments();
            return request.CreateResponse(HttpStatusCode.OK,_result );
        }

        
        [Route("GetAllManagers")]
        [HttpGet]
        public HttpResponseMessage GetAllManagers(HttpRequestMessage request)
        {
            SampleDataAppService objSampleDataService = new SampleDataAppService();
            var _result = objSampleDataService.GetAllManagers();
            return request.CreateResponse(HttpStatusCode.OK, _result);
        }
        [Route("UpdateManager")]
        [HttpPost]
        public HttpResponseMessage UpdateManager(HttpRequestMessage request, ManagerUpdateParam objUpdateParam)
        {
            SampleDataAppService objSampleDataService = new SampleDataAppService();
            var _result = objSampleDataService.GetAllManagers();
            return request.CreateResponse(HttpStatusCode.OK, _result);
        }
         
    }
}