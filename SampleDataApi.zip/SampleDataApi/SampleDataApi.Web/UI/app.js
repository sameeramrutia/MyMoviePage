﻿angular.module('sampleDataApp', ['smart-table']);
    