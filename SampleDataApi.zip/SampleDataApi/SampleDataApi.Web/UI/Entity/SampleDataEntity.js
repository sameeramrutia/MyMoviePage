﻿(function () {
    angular.module("sampleDataApp").factory('sampleDataEntity', sampleDataEntity);
    sampleDataEntity.$inject = [];
    function sampleDataEntity() {
        var entity = this
        Object.defineProperties(entity, {
            sampleAppData: {
                value: [],
                writable: true,
                enumrable: true,
                configurable:true
            },
            managerData: {
                value: [],
                writable: true,
                enumrable: true,
                configurable: true
            }
        });

        return entity;
    }
}());