﻿//angular.module("sampleDataApp").factory("sampleDataFactory", function ($http) {
//    var url = "http://localhost:1614/api/Data/";
//    var getAllUserDataMethodName = "GetAllUsers"
//    var getAllManagerMethodName = "GetAllUsers"
//    var getAllManagers_old = function () {
//        return $http({
//            method: 'GET',
//            url: url+ getAllUserDataMethodName,
//            params: null
//        }).success(function (data) {
//            return data;
//        }).error(function () {
//            alert("error");
//        });
//    }

//    function getAllUserData() {
//        return $http.get(url+getAllUserDataMethodName)
//           .then(function (response) {
//               return response.data;
//           });
//    };
//    function getAllManagers() {
//        return $http.get(url + getAllManagerMethodName)
//           .then(function (response) {
//               return response.data;
//           });
//    };

//    return {
//        getAllUserData: getAllUserData,
//        getAllManagers: getAllManagers
//    };
//});

(function () {
    angular.module('sampleDataApp').factory("sampleDataFactory", sampleDataFactory);

    sampleDataFactory.$inject = ['$http', 'sampleDataEntity'];
    function sampleDataFactory($http, sampleDataEntity) {
        var url = "http://localhost:1614/api/Data/";
        var getAllUserDataMethodName = "GetAllUsers";
        var getAllManagerMethodName = "GetAllManagers";
        var updateManagerMethodName = "UpdateManager";

        return {
            getAllUserData: getAllUserData,
            getAllManagers: getAllManagers,
            sampleDataEntity: sampleDataEntity,
            updateManager: updateManager,
            updateUser: updateUser
        };
        function getAllUserData() {
            return $http.get(url + getAllUserDataMethodName)
               .then(function (response) {
                   sampleDataEntity.sampleAppData = response.data;
                   return $http.get(url + getAllManagerMethodName)
                       .then(function (response) {
                           sampleDataEntity.managerData = response.data;
                           return response.data;
                       });
                   //return response.data;
               });
        };
        function getAllManagers() {
            return $http.get(url + getAllManagerMethodName)
               .then(function (response) {
                   sampleDataEntity.managerData = response.data;
                   return response.data;
               });
        };
        function updateManager(objUpdateParam) {
            return $http.post(url + updateManagerMethodName, objUpdateParam)
                .then(function (data) {
                    getAllUserData().then(function (data) {
                    });
            });
        };
        function updateUser(objUpdateParam) {
            return "";
        }
    };
}());