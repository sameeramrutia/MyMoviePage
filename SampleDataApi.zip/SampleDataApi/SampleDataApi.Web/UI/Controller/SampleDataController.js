﻿angular.module("sampleDataApp").controller("sampleDataController", function ($scope,$interval, sampleDataFactory) {
  
    var vm = this  
    
    sampleDataFactory.getAllUserData().then(function (data) {
        vm.model = sampleDataFactory.sampleDataEntity;
    });
    

    vm.clock = { time: "", interval: 1000 };
    $interval(function () {
        vm.clock.time = Date.now();
    },
    vm.clock.interval);

    vm.updateUser = function (user) {
        
        user.IsEdit = 0;
        var objUpdateParam = {
            UserId: user.UserId,
            ManagerId: user.SelectedManager.ManagerId
        }
       // sampleDataFactory.updateUser(objUpdateParam);
        sampleDataFactory.updateManager(objUpdateParam).then(function (data) {
            vm.model = sampleDataFactory.sampleDataEntity;
        });
    };
});