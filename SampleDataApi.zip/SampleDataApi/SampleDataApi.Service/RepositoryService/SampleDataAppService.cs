﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SampleDataApi.Service.Interface;
using SampleDataApi.Entity;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using SampleDataApi.Service.Helper;


namespace SampleDataApi.Service.RepositoryService
{
    public class SampleDataAppService :ISampleDataApp
    {

        
        public List<User> GetAllUsers()
        {
            List<User> objUserList = new List<User>();

            DataSet ds = new DataSet();
            ds = DBHelper.ExecuteDataset(Constants.SPROC_GETALLUSERS);
            if (ds.Tables.Count > 0)
            {
                objUserList = (from DataRow dr in ds.Tables[0].Rows
                               select new User
                               {
                                   UserId = Convert.ToInt32(dr["UserId"]),
                                   UserName = dr["UserName"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["UserName"]),
                                   DepartmentName = dr["DepartmentName"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["DepartmentName"]),
                                   ManagerName = dr["ManagerName"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["ManagerName"]),
                                   RoleName = dr["Role"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["Role"]),
                                   Address = dr["Address"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["Address"]),
                                   ManagerId = dr["ManagerId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["ManagerId"]),
                                   DepartmentId = dr["DepartmentId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["DepartmentId"]),
                                   BuildingId = dr["BuildingId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["BuildingId"]),
                                   RoleId = dr["RoleId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["RoleId"]),
                                   IsEdit = 0,
                                   IsManager = dr["IsManager"].Equals(DBNull.Value) ? false : Convert.ToBoolean(dr["IsManager"])

                               }
                ).ToList();
            }

            return objUserList;
        }
        public List<Department> GetAllDepartments()
        {
            List<Department> objDepartmentList = new List<Department>();

            DataSet ds = new DataSet();
            ds = DBHelper.ExecuteDataset(Constants.SPROC_GETALLDEPARTMENTS);
            if (ds.Tables.Count > 0)
            {
                objDepartmentList = (from DataRow dr in ds.Tables[0].Rows
                               select new Department
                               {                                   
                                   DepartmentName = dr["DepartmentName"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["DepartmentName"]),                                  
                                   DepartmentId = dr["DepartmentId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["DepartmentId"])                                  
                               }
                ).ToList();
            }

            return objDepartmentList;
        }
        public List<Role> GetAllRoles()
        {
            List<Role> objRoleList = new List<Role>();

            DataSet ds = new DataSet();
            ds = DBHelper.ExecuteDataset(Constants.SPROC_GETALLROLES);
            if (ds.Tables.Count > 0)
            {
                objRoleList = (from DataRow dr in ds.Tables[0].Rows
                               select new Role
                               {
                                   RoleName = dr["Role"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["Role"]),
                                   RoleId = dr["RoleId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["RoleId"]),
                                   IsManager = dr["IsManager"].Equals(DBNull.Value) ? false : Convert.ToBoolean(dr["IsManager"])
                               }
                ).ToList();
            }

            return objRoleList;
        }
        public List<Building> GetAllBuilding()
        {
            List<Building> objBuildingList = new List<Building>();

            DataSet ds = new DataSet();
            ds = DBHelper.ExecuteDataset(Constants.SPROC_GETALLBUILDINGS);
            if (ds.Tables.Count > 0)
            {
                objBuildingList = (from DataRow dr in ds.Tables[0].Rows
                                     select new Building
                                     {

                                         BuildingId = dr["BuildingId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["BuildingId"]),
                                         Address = dr["Address"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["Address"]),
                                         BuildingName = dr["BuildingName"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["BuildingName"])

                                     }
                ).ToList();
            }

            return objBuildingList;
        }

        public List<Manager> GetAllManagers()
        {
            List<Manager> objManagerList = new List<Manager>();

            DataSet ds = new DataSet();
            ds = DBHelper.ExecuteDataset(Constants.SPROC_GETALLMANAGERS);
            if (ds.Tables.Count > 0)
            {
                objManagerList = (from DataRow dr in ds.Tables[0].Rows
                                   select new Manager
                                   {

                                       ManagerId = dr["ManagerId"].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr["ManagerId"]),
                                       ManagerName = dr["ManagerName"].Equals(DBNull.Value) ? "" : Convert.ToString(dr["ManagerName"])


                                   }
                ).ToList();
            }

            return objManagerList;
        }
        public void UpdateUserManager(ManagerUpdateParam objMangerUpdateParam)
        {            
            var conn = new SqlConnection(DBHelper.DefaultConnectionString);
            try
            {               
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = Constants.SPROC_UPDATEUSERMANAGER;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@UserId", objMangerUpdateParam.UserId));
                cmd.Parameters.Add(new SqlParameter("@ManagerId", objMangerUpdateParam.ManagerId));

                cmd.ExecuteNonQuery();
                conn.Close();
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }
    }
}
