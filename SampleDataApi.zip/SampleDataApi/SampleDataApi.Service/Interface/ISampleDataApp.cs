﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SampleDataApi.Entity;

namespace SampleDataApi.Service.Interface
{
    public interface ISampleDataApp
    {
        List<User> GetAllUsers();
        List<Building> GetAllBuilding();
        List<Role> GetAllRoles();
        List<Department> GetAllDepartments();
        List<Manager> GetAllManagers();
        void UpdateUserManager(ManagerUpdateParam objMangerUpdateParam);
    }
}
