﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace SampleDataApi.Service.Helper
{
    public static class Constants
    {
       // public const string SAMPLEDB_CONNECTION = System.Configuration.ConfigurationManager.ConnectionStrings
        public const string SPROC_GETALLUSERS = "dbo.GetAllUsers";
        public const string SPROC_GETALLDEPARTMENTS = "dbo.GetAllDepartments";
        public const string SPROC_GETALLROLES = "dbo.GetAllRoles";
        public const string SPROC_GETALLBUILDINGS = "dbo.GetAllBuildings";
        public const string SPROC_GETALLMANAGERS = "dbo.GetAllManagers";
        public const string SPROC_UPDATEUSERMANAGER = "dbo.UpdateUserManager";
    }
}
